
# coding: utf-8

# This notebook builds the similarity matrix used in the construction of the network to which spectral clustering is applied. 

import numpy as np
import pandas as pd
import warnings 
from scipy import sparse
import sys
import argparse


# All the comparison work is performed in __tmscorePreloaded.py__.  In particular, the primary structure of the two proteins to be compared are aligned, and then the tertiary structures corresponding to that alignment are scored using a Template Model Score algorithm.  


import tmscorePreloaded as tmscore

if __name__ == '__main__':
    # process arguments. Currently there are none, but for HPC approach likely one would want 
    # to modify the final loop structure below to run across several processors 
    
    # Loop range:    
    Begin = 1 
    End = -1  # Will be set to length of list if negative 

    #parser = argparse.ArgumentParser()
    #parser.add_argument('nums', nargs=2)
    #args = parser.parse_args()
    #assert len(args.nums) == 2,  "Two arguments required"
    #Begin, End = args.nums  
    #assert Begin < End, "Second Argument must be larger than the First"
    

    #load the pdb file names and which of the chains in those files is to be used for the comparisons.  
    SerProtPFam = pd.read_csv('pbd_chain_uniprotPF00089.csv')
    SerProtPFam.head()


    # Build all the structures that are to be compared against each other. 
    Structures = []
    PDBs = []

    for i in range(len(SerProtPFam)):
        pdb_i   = SerProtPFam.loc[i,'PDB']
        chain_i = SerProtPFam.loc[i,'CHAIN']
        FNi = r'SP\pdb%s.ent' % pdb_i
        
        try:
            structure = parser.get_structure(chain_i, FNi)
            structure = ppb.build_peptides(structure)[0]
        except:
            structure = []
     
        Structures.append(structure)
        PDBs.append(pdb_i)

    assert Begin > 0, "First argument must be a positive integer"
    assert End <= len(PDBs), "Second Argument cannot exceed %s" % len(PDBs)

    ## If End = -1, then set it to length of PDBs
    if End < 0: End = len(PDBs)

    N = len(SerProtPFam)
    Sims = np.zeros( (N,N) )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")


        for i in range(Begin,End):
            pdb_i   = PDBs[i]
            s_i = Structures[i]
            for j in range(i+1,N):
                pdb_j   = PDBs[j]
                s_j = Structures[j]

                try:
                    val = tmscore.TMscoring(s_i, s_j)
                    _, tm, rmsd = val.optimise()
                    Sims[i,j] = Sims[i,j] = tm
                except:
                    print("Error in comparing %s and %s" % (pdb_i,pdb_j))
            if(i % 10 == 0): 
                np.savetxt('Sims.txt',Sims)
                print("JUST COMPLETED STEP %s" % i)


    # Sims as a sparse matrix for those who just want to reconstruct the network and perform the clustering.  
    Simsparse = sparse.csr_matrix(Sims)
    sparse.save_npz('SimilarityMatrix.npz',Simsparse)

